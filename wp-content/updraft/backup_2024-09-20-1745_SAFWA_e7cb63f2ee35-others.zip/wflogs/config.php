<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:7:{s:9:"wafStatus";s:13:"learning-mode";s:30:"learningModeGracePeriodEnabled";i:1;s:23:"learningModeGracePeriod";i:1727442590;s:7:"authKey";s:64:"kGhP@d7a$AY]vy,OND`x,)G/{)`-,IZ)9?eJ$v 2(VLKTzMsSY<|Kz:lV^!Wr=wB";s:7:"version";s:5:"1.1.0";s:11:"wafDisabled";b:1;s:13:"attackDataKey";i:2393;}