<article <?php post_class( 'post_item_single post_item_404' ); ?>>
	<div class="post_content">
		<h1 class="page_title"><?php esc_html_e( '404', 'agricola' ); ?></h1>
		<div class="page_info">
			<h2 class="page_subtitle"><?php esc_html_e( 'Oops...', 'agricola' ); ?></h2>
			<p class="page_description"><?php echo wp_kses( __( "We're sorry, but <br>something went wrong.", 'agricola' ), 'agricola_kses_content' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="go_home theme_button"><?php esc_html_e( 'Homepage', 'agricola' ); ?></a>
		</div>

		<?php
		// SVG
		$svg_bg_1 = agricola_get_svg_from_file(agricola_get_file_dir('images/decoration-1.svg'));
		$svg_bg_2 = agricola_get_svg_from_file(agricola_get_file_dir('images/decoration-2.svg'));
		$svg_bg_3 = agricola_get_svg_from_file(agricola_get_file_dir('images/decoration-3.svg'));
		$svg_bg = ($svg_bg_1 ? '<span class="svg-1">'.$svg_bg_1.'</span>' : '').($svg_bg_2 ? '<span class="svg-2">'.$svg_bg_2.'</span>' : '').($svg_bg_3 ? '<span class="svg-3">'.$svg_bg_3.'</span>' : '');
		if(!empty($svg_bg)){ ?>
		<div class="all-svg">
			<?php agricola_show_layout($svg_bg); ?>
		</div>
		<?php }	?>

	</div>
</article>